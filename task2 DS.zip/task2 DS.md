```python
#Import Libraries
import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import seaborn as sns  

```


```python
#Load the Dataset
df = pd.read_csv(r"C:\Users\MADHU\Desktop\Global_Superstore.csv", encoding="ISO-8859-1")
```


```python
#Initial Data Exploration
print(df.head())  # Display first 5 rows
print(df.shape)  # Print number of rows & columns
print(df.info())  # Summary of dataset
print(df.describe())  # Summary statistics for numerical columns

```

       Row ID         Order ID  Order Date   Ship Date     Ship Mode Customer ID  \
    0   32298   CA-2012-124891  31-07-2012  31-07-2012      Same Day    RH-19495   
    1   26341    IN-2013-77878  05-02-2013  07-02-2013  Second Class    JR-16210   
    2   25330    IN-2013-71249  17-10-2013  18-10-2013   First Class    CR-12730   
    3   13524  ES-2013-1579342  28-01-2013  30-01-2013   First Class    KM-16375   
    4   47221     SG-2013-4320  05-11-2013  06-11-2013      Same Day     RH-9495   
    
          Customer Name      Segment           City            State  ...  \
    0       Rick Hansen     Consumer  New York City         New York  ...   
    1     Justin Ritter    Corporate     Wollongong  New South Wales  ...   
    2      Craig Reiter     Consumer       Brisbane       Queensland  ...   
    3  Katherine Murray  Home Office         Berlin           Berlin  ...   
    4       Rick Hansen     Consumer          Dakar            Dakar  ...   
    
             Product ID  Prosuct Categories Sub-Category  \
    0   TEC-AC-10003033          Technology  Accessories   
    1   FUR-CH-10003950           Furniture       Chairs   
    2   TEC-PH-10004664          Technology       Phones   
    3   TEC-PH-10004583          Technology       Phones   
    4  TEC-SHA-10000501          Technology      Copiers   
    
                                            Product Name     Sales Quantity  \
    0  Plantronics CS510 - Over-the-Head monaural Wir...  2309.650        7   
    1          Novimex Executive Leather Armchair, Black  3709.395        9   
    2                  Nokia Smart Phone, with Caller ID  5175.171        9   
    3                     Motorola Smart Phone, Cordless  2892.510        5   
    4                     Sharp Wireless Fax, High-Speed  2832.960        8   
    
      Discount    Profit  Shipping Cost  Order Priority  
    0      0.0  762.1845         933.57        Critical  
    1      0.1 -288.7650         923.63        Critical  
    2      0.1  919.9710         915.49          Medium  
    3      0.1  -96.5400         910.16          Medium  
    4      0.0  311.5200         903.04        Critical  
    
    [5 rows x 24 columns]
    (51290, 24)
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 51290 entries, 0 to 51289
    Data columns (total 24 columns):
     #   Column              Non-Null Count  Dtype  
    ---  ------              --------------  -----  
     0   Row ID              51290 non-null  int64  
     1   Order ID            51290 non-null  object 
     2   Order Date          51290 non-null  object 
     3   Ship Date           51290 non-null  object 
     4   Ship Mode           51290 non-null  object 
     5   Customer ID         51290 non-null  object 
     6   Customer Name       51290 non-null  object 
     7   Segment             51290 non-null  object 
     8   City                51290 non-null  object 
     9   State               51290 non-null  object 
     10  Country             51290 non-null  object 
     11  Postal Code         9994 non-null   float64
     12  Market              51290 non-null  object 
     13  Region              51290 non-null  object 
     14  Product ID          51290 non-null  object 
     15  Prosuct Categories  51290 non-null  object 
     16  Sub-Category        51290 non-null  object 
     17  Product Name        51290 non-null  object 
     18  Sales               51290 non-null  float64
     19  Quantity            51290 non-null  int64  
     20  Discount            51290 non-null  float64
     21  Profit              51290 non-null  float64
     22  Shipping Cost       51290 non-null  float64
     23  Order Priority      51290 non-null  object 
    dtypes: float64(5), int64(2), object(17)
    memory usage: 9.4+ MB
    None
                Row ID   Postal Code         Sales      Quantity      Discount  \
    count  51290.00000   9994.000000  51290.000000  51290.000000  51290.000000   
    mean   25645.50000  55190.379428    246.490581      3.476545      0.142908   
    std    14806.29199  32063.693350    487.565361      2.278766      0.212280   
    min        1.00000   1040.000000      0.444000      1.000000      0.000000   
    25%    12823.25000  23223.000000     30.758625      2.000000      0.000000   
    50%    25645.50000  56430.500000     85.053000      3.000000      0.000000   
    75%    38467.75000  90008.000000    251.053200      5.000000      0.200000   
    max    51290.00000  99301.000000  22638.480000     14.000000      0.850000   
    
                 Profit  Shipping Cost  
    count  51290.000000   51290.000000  
    mean      28.610982      26.375915  
    std      174.340972      57.296804  
    min    -6599.978000       0.000000  
    25%        0.000000       2.610000  
    50%        9.240000       7.790000  
    75%       36.810000      24.450000  
    max     8399.976000     933.570000  
    


```python
#Handle Missing Values
print(df.isnull().sum())  # Count missing values in each column

```

    Row ID                    0
    Order ID                  0
    Order Date                0
    Ship Date                 0
    Ship Mode                 0
    Customer ID               0
    Customer Name             0
    Segment                   0
    City                      0
    State                     0
    Country                   0
    Postal Code           41296
    Market                    0
    Region                    0
    Product ID                0
    Prosuct Categories        0
    Sub-Category              0
    Product Name              0
    Sales                     0
    Quantity                  0
    Discount                  0
    Profit                    0
    Shipping Cost             0
    Order Priority            0
    dtype: int64
    


```python
#Numerical Columns → Fill with mean or median
df['Sales'].fillna(df['Sales'].median(), inplace=True)

```


```python
#Categorical Columns → Fill with mode or 'Unknown'
df['Region'].fillna(df['Region'].mode()[0], inplace=True)

```


```python
#Drop rows with many missing values
df.dropna(inplace=True)

```


```python
#Remove Duplicates
print(df.duplicated().sum())  # Count duplicates
df.drop_duplicates(inplace=True)  # Remove duplicates
```

    0
    


```python
#Handle Outliers
#Use Interquartile Range (IQR) Method
Q1 = df['Sales'].quantile(0.25)
Q3 = df['Sales'].quantile(0.75)
IQR = Q3 - Q1

lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR

df = df[(df['Sales'] >= lower_bound) & (df['Sales'] <= upper_bound)]

```


```python
#Use Z-score Method
from scipy import stats
df = df[(np.abs(stats.zscore(df['Sales'])) < 3)]

```


```python
#Compute Statistical Measures
print("Mean Sales:", df["Sales"].mean())
print("Median Sales:", df["Sales"].median())
print("Standard Deviation:", df["Sales"].std())
print("Variance:", df["Sales"].var())

```

    Mean Sales: 84.1313796405797
    Median Sales: 39.68
    Standard Deviation: 99.84911479718176
    Variance: 9969.84572578078
    


```python
#Data Visualization
#Histogram - Distribution of Sales
plt.figure(figsize=(8, 5))
sns.histplot(df["Sales"], bins=30, kde=True)
plt.title("Sales Distribution")
plt.show()

```

    C:\Users\MADHU\anaconda3\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_11_1.png)
    



```python
#Boxplot - Identifying Outliers in Profit
plt.figure(figsize=(8, 5))
sns.boxplot(x=df["Profit"])
plt.title("Boxplot of Profit")
plt.show()

```


    
![png](output_12_0.png)
    



```python
#Heatmap - Correlation Matrix
plt.figure(figsize=(10, 6))

# Select only numeric columns for correlation
numeric_df = df.select_dtypes(include=["number"])

sns.heatmap(numeric_df.corr(), annot=True, cmap="coolwarm", linewidths=0.5)
plt.title("Correlation Matrix")
plt.show()

```


    
![png](output_13_0.png)
    



```python
from sklearn.preprocessing import LabelEncoder

# Convert categorical columns to numeric
categorical_cols = df.select_dtypes(include=["object"]).columns

encoder = LabelEncoder()
for col in categorical_cols:
    df[col] = encoder.fit_transform(df[col])

# Now plot the heatmap
sns.heatmap(df.corr(), annot=True, cmap="coolwarm", linewidths=0.5)
plt.title("Correlation Matrix")
plt.show()

```

    C:\Users\MADHU\anaconda3\Lib\site-packages\seaborn\matrix.py:260: FutureWarning: Format strings passed to MaskedConstant are ignored, but in future may error or produce different behavior
      annotation = ("{:" + self.fmt + "}").format(val)
    


    
![png](output_14_1.png)
    



```python
#Bar Chart - Sales by Region
plt.figure(figsize=(10, 6))
sns.barplot(x="Region", y="Sales", data=df, estimator=np.sum)
plt.title("Total Sales by Region")
plt.xticks(rotation=45)
plt.show()

```


    
![png](output_15_0.png)
    



```python
#Save Cleaned Dataset
df.to_csv("Cleaned_Global_Superstore.csv", index=False)

```


```python

```
