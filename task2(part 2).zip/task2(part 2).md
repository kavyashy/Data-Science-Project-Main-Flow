```python
#Load and Explore the Dataset
import pandas as pd
import numpy as np

# Load the dataset
df = pd.read_csv(r"C:\Users\MADHU\Desktop\Global_Superstore.csv",encoding='ISO-8859-1')

# Check the first few rows
print(df.head())

# Get dataset info (data types, missing values, etc.)
print(df.info())

# Summary statistics
print(df.describe())

# Check for missing values
print(df.isnull().sum())

```

       Row ID         Order ID        Date   Ship Date     Ship Mode Customer ID  \
    0   32298   CA-2012-124891  31-07-2012  31-07-2012      Same Day    RH-19495   
    1   26341    IN-2013-77878  05-02-2013  07-02-2013  Second Class    JR-16210   
    2   25330    IN-2013-71249  17-10-2013  18-10-2013   First Class    CR-12730   
    3   13524  ES-2013-1579342  28-01-2013  30-01-2013   First Class    KM-16375   
    4   47221     SG-2013-4320  05-11-2013  06-11-2013      Same Day     RH-9495   
    
          Customer Name      Segment           City            State  ...  \
    0       Rick Hansen     Consumer  New York City         New York  ...   
    1     Justin Ritter    Corporate     Wollongong  New South Wales  ...   
    2      Craig Reiter     Consumer       Brisbane       Queensland  ...   
    3  Katherine Murray  Home Office         Berlin           Berlin  ...   
    4       Rick Hansen     Consumer          Dakar            Dakar  ...   
    
             Product ID    Category Sub-Category  \
    0   TEC-AC-10003033  Technology  Accessories   
    1   FUR-CH-10003950   Furniture       Chairs   
    2   TEC-PH-10004664  Technology       Phones   
    3   TEC-PH-10004583  Technology       Phones   
    4  TEC-SHA-10000501  Technology      Copiers   
    
                                                 Product     Sales Quantity  \
    0  Plantronics CS510 - Over-the-Head monaural Wir...  2309.650        7   
    1          Novimex Executive Leather Armchair, Black  3709.395        9   
    2                  Nokia Smart Phone, with Caller ID  5175.171        9   
    3                     Motorola Smart Phone, Cordless  2892.510        5   
    4                     Sharp Wireless Fax, High-Speed  2832.960        8   
    
      Discount    Profit  Shipping Cost  Order Priority  
    0      0.0  762.1845         933.57        Critical  
    1      0.1 -288.7650         923.63        Critical  
    2      0.1  919.9710         915.49          Medium  
    3      0.1  -96.5400         910.16          Medium  
    4      0.0  311.5200         903.04        Critical  
    
    [5 rows x 24 columns]
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 51290 entries, 0 to 51289
    Data columns (total 24 columns):
     #   Column          Non-Null Count  Dtype  
    ---  ------          --------------  -----  
     0   Row ID          51290 non-null  int64  
     1   Order ID        51290 non-null  object 
     2   Date            51290 non-null  object 
     3   Ship Date       51290 non-null  object 
     4   Ship Mode       51290 non-null  object 
     5   Customer ID     51290 non-null  object 
     6   Customer Name   51290 non-null  object 
     7   Segment         51290 non-null  object 
     8   City            51290 non-null  object 
     9   State           51290 non-null  object 
     10  Country         51290 non-null  object 
     11  Postal Code     9994 non-null   float64
     12  Market          51290 non-null  object 
     13  Region          51290 non-null  object 
     14  Product ID      51290 non-null  object 
     15  Category        51290 non-null  object 
     16  Sub-Category    51290 non-null  object 
     17  Product         51290 non-null  object 
     18  Sales           51290 non-null  float64
     19  Quantity        51290 non-null  int64  
     20  Discount        51290 non-null  float64
     21  Profit          51290 non-null  float64
     22  Shipping Cost   51290 non-null  float64
     23  Order Priority  51290 non-null  object 
    dtypes: float64(5), int64(2), object(17)
    memory usage: 9.4+ MB
    None
                Row ID   Postal Code         Sales      Quantity      Discount  \
    count  51290.00000   9994.000000  51290.000000  51290.000000  51290.000000   
    mean   25645.50000  55190.379428    246.490581      3.476545      0.142908   
    std    14806.29199  32063.693350    487.565361      2.278766      0.212280   
    min        1.00000   1040.000000      0.444000      1.000000      0.000000   
    25%    12823.25000  23223.000000     30.758625      2.000000      0.000000   
    50%    25645.50000  56430.500000     85.053000      3.000000      0.000000   
    75%    38467.75000  90008.000000    251.053200      5.000000      0.200000   
    max    51290.00000  99301.000000  22638.480000     14.000000      0.850000   
    
                 Profit  Shipping Cost  
    count  51290.000000   51290.000000  
    mean      28.610982      26.375915  
    std      174.340972      57.296804  
    min    -6599.978000       0.000000  
    25%        0.000000       2.610000  
    50%        9.240000       7.790000  
    75%       36.810000      24.450000  
    max     8399.976000     933.570000  
    Row ID                0
    Order ID              0
    Date                  0
    Ship Date             0
    Ship Mode             0
    Customer ID           0
    Customer Name         0
    Segment               0
    City                  0
    State                 0
    Country               0
    Postal Code       41296
    Market                0
    Region                0
    Product ID            0
    Category              0
    Sub-Category          0
    Product               0
    Sales                 0
    Quantity              0
    Discount              0
    Profit                0
    Shipping Cost         0
    Order Priority        0
    dtype: int64
    


```python
#Data Cleaning
#Remove Duplicates
df.drop_duplicates(inplace=True)

```


```python
#Fill Missing Values
#Numerical columns (e.g., Sales, Profit) → Fill with mean or median
df['Sales'].fillna(df['Sales'].median(), inplace=True)
df['Profit'].fillna(df['Profit'].median(), inplace=True)

```


```python
#Categorical columns (e.g., Region, Category) → Fill with mode or 'Unknown'
df['Region'].fillna(df['Region'].mode()[0], inplace=True)
df['Category'].fillna(df['Category'].mode()[0], inplace=True)

```


```python
# Convert Date Column to DateTime
df['Date'] = pd.to_datetime(df['Date'])

```

    C:\Users\MADHU\AppData\Local\Temp\ipykernel_7668\3693369917.py:2: UserWarning: Parsing dates in %d-%m-%Y format when dayfirst=False (the default) was specified. Pass `dayfirst=True` or specify a format to silence this warning.
      df['Date'] = pd.to_datetime(df['Date'])
    


```python
#Exploratory Data Analysis (EDA)
#Time Series Plot for Sales Trends
import matplotlib.pyplot as plt

# Group by date to calculate daily sales
df['Year-Month'] = df['Date'].dt.to_period('M')
sales_trends = df.groupby('Year-Month')['Sales'].sum()

# Plot the time series
plt.figure(figsize=(10, 6))
sales_trends.plot(kind='line', marker='o')
plt.title("Sales Trends Over Time")
plt.xlabel("Date")
plt.ylabel("Total Sales")
plt.xticks(rotation=45)
plt.show()

```


    
![png](output_5_0.png)
    



```python
#Scatter Plot: Profit vs. Discount
import seaborn as sns

# Scatter plot
plt.figure(figsize=(8, 5))
sns.scatterplot(x='Discount', y='Profit', data=df)
plt.title("Profit vs Discount")
plt.xlabel("Discount")
plt.ylabel("Profit")
plt.show()

```


    
![png](output_6_0.png)
    



```python
# Bar plot for Sales by Region
plt.figure(figsize=(10, 6))
sns.barplot(x="Region", y="Sales", data=df, estimator=np.sum)
plt.title("Sales by Region")
plt.xticks(rotation=45)
plt.show()

```


    
![png](output_7_0.png)
    



```python
# Pie chart for Sales by Category
category_sales = df.groupby('Category')['Sales'].sum()
category_sales.plot(kind='pie', autopct='%1.1f%%', figsize=(8, 8))
plt.title("Sales Distribution by Category")
plt.ylabel("")
plt.show()

```


    
![png](output_8_0.png)
    



```python
#Predictive Modeling (Linear Regression)
#Prepare the Data for Modeling

# Select relevant columns for modeling
X = df[['Profit', 'Discount']]  # Features
y = df['Sales']  # Target variable

# Split data into training and testing sets
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

```


```python
#Train the Linear Regression Model
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Initialize and train the model
model = LinearRegression()
model.fit(X_train, y_train)

# Predict on the test set
y_pred = model.predict(X_test)

# Evaluate the model
print("Mean Squared Error:", mean_squared_error(y_test, y_pred))
print("R-squared:", r2_score(y_test, y_pred))

```

    Mean Squared Error: 187787.80150462044
    R-squared: 0.16090406163840798
    


```python

```
